# Extstats MCP Server

A Model Context Protocol (MCP) server built with mcp-framework.
Note that mcp-framework requires version 3 of Zod, it won't compile with version 4.

## Project Structure

```
my-mcp-server/
├── src/
│   ├── tools/        # MCP Tools
│   │   └── ExampleTool.ts
│   └── index.ts      # Server entry point
├── package.json
└── tsconfig.json
```